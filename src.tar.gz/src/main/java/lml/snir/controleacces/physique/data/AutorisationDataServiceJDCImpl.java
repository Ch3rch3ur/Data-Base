package lml.snir.controleacces.physique.data;

import java.util.List;
import java.util.Map;
import lml.snir.persistence.jdbc.AbstractCrudServiceJDBC;
import lml.snir.controleacces.metier.entity.Autorisation;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.controleacces.metier.entity.Salle;
import lml.snir.controleacces.metier.entity.TimeSlot;

/**
 *
 * @author fanou
 */
final class AutorisationDataServiceJDCImpl<T> extends AbstractCrudServiceJDBC<Autorisation> implements AutorisationDataService {

    AutorisationDataServiceJDCImpl() throws Exception {
        try {
            String query = null;

            switch (super.getDBType()) {
                case MYSQL:
                    query = "CREATE TABLE IF NOT EXISTS `" + super.getEntityName() + "` (\n"
                            + "  `id` int(11) NOT NULL AUTO_INCREMENT,\n"
                            + "  `idSalle` int(11) NOT NULL,\n"
                            + "  `idPersonne` int(11) NOT NULL,\n"
                            + "  `idPlageHoraire` int(11) NOT NULL,\n"
                            + "  PRIMARY KEY (`id`)\n"
                            + ") ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";
                    break;
                case SQLITE:
                    query = "CREATE TABLE IF NOT EXISTS `" + super.getEntityName() + "` (\n"
                            + "  `id` INTEGER PRIMARY KEY AUTOINCREMENT,\n" // int(11) NOT NULL
                            + "  `idSalle` int(11) NOT NULL,\n"
                            + "  `idPersonne` int(11) NOT NULL,\n"
                            + "  `idPlageHoraire` int(11) NOT NULL\n"
                            + ");";
                    break;
            }
            super.executeQuery(query);

        } catch (Exception ex) {
            System.out.println(this.getClass().getSimpleName() + "\n" + super.getDBType() + "\n" + ex);
        }
    }

    @Override
    protected Autorisation createEntity(Map map) throws Exception {
        Autorisation autorisation;

        long id = (int) map.get("id");
        long idSalle = (int) map.get("idSalle");
        long idPersonne = (int) map.get("idPersonne");
        long idPlageHoraire = (int) map.get("idPlageHoraire");

        autorisation = new Autorisation();
        autorisation.setId(id);
        Personne personne = PhysiqueDataFactory.getPersonneDataService().getById(idPersonne);
        Salle salle = PhysiqueDataFactory.getSalleDataService().getById(idSalle);
        TimeSlot plageHoraire = PhysiqueDataFactory.getTimeSlotService().getById(idPlageHoraire);
        autorisation.setPersonne(personne);
        autorisation.setPlageHoraire(plageHoraire);
        autorisation.setSalle(salle);

        return autorisation;
    }

    @Override
    public Autorisation add(Autorisation autorisation) throws Exception {
        String query = "INSERT INTO " + super.getEntityName() + " (idSalle, idPersonne, idPlageHoraire) VALUES ('"
                + autorisation.getSalle().getId() + "','"
                + autorisation.getPersonne().getId() + "','"
                + autorisation.getPlageHoraire().getId() + "')";
        autorisation.setId(super.executeAdd(query));
        return autorisation;
    }

    @Override
    public void remove(Autorisation autorisation) throws Exception {
        String query = "DELETE FROM " + super.getEntityName() + " WHERE id = '" + autorisation.getId() + "'";
        super.executeQuery(query);
    }

    @Override
    public void update(Autorisation autorisation) throws Exception {
        String query = "UPDATE " + super.getEntityName() + " SET id = '"
                + autorisation.getId() + "', idSalle = '"
                + autorisation.getSalle().getId() + "',  idPersonne = '"
                + autorisation.getPersonne().getId() + "',  idPlageHoraire = '"
                + autorisation.getPlageHoraire().getId() + "' WHERE id = '" + autorisation.getId() + "'";

        super.executeQuery(query);
    }

    @Override
    public List<Autorisation> getBySalle(Salle salle) throws Exception {
        String query = "SELECT * FROM " + super.getEntityName() + " WHERE idSalle = '" + salle.getId() + "'";
        return super.getResults(query);
    }

    @Override
    public List<Autorisation> getByPersonne(Personne personne) throws Exception {
        String query = "SELECT * FROM " + super.getEntityName() + " WHERE idPersonne = '" + personne.getId() + "'";
        return super.getResults(query);
    }

    @Override
    public List<Autorisation> getByPlageHoraire(TimeSlot plageHoraire) throws Exception {
        String query = "SELECT * FROM " + super.getEntityName() + " WHERE idPlageHoraire = '" + plageHoraire.getId() + "'";
        return super.getResults(query);
    }

    @Override
    public List<Autorisation> getByPeronneEtSalle(Personne personne, Salle salle) throws Exception {
        String query = "SELECT * FROM " + super.getEntityName() + " WHERE idPersonne = '" + personne.getId() + "' AND idSalle = '" + salle.getId() + "'";
        return super.getResults(query);
    }
}
