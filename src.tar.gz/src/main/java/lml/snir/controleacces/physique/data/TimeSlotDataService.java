package lml.snir.controleacces.physique.data;

import lml.snir.persistence.CrudService;
import lml.snir.controleacces.metier.entity.TimeSlot;

/**
 *
 * @author fanou
 */
public interface TimeSlotDataService extends CrudService<TimeSlot>{
    
}
