package lml.snir.controleacces.physique.data;


/**
 *
 * @author fanou
 */
public class PhysiqueDataFactory {

    private PhysiqueDataFactory() {
    }

    private static AttributionDataService attributionDataService = null;
    public static AttributionDataService getAttributionDataService() throws Exception {
        if (attributionDataService == null) {
            attributionDataService = new AttributionDataServiceJDBCImpl();
        }
        return attributionDataService;
    }

    private static SalleDataService salleDataService = null;
    public static SalleDataService getSalleDataService() throws Exception {
        if (salleDataService == null) {
            salleDataService = new SalleDataServiceJDBCImpl();
        }
        return salleDataService;
    }

    private static AutorisationDataService autorisationDataService = null;
    public static AutorisationDataService getAutorisationDataService() throws Exception {
        if (autorisationDataService == null) {
            autorisationDataService = new AutorisationDataServiceJDCImpl();
        }
        return autorisationDataService;
    }

    private static BadgeDataService badgeDataService = null;
    public static BadgeDataService getBadgeDataService() throws Exception {
        if (badgeDataService == null) {
            badgeDataService = new BadgeDataServiceJDBCImpl();
        }
        return badgeDataService;
    }

    

    private static EvenementDataService evenementDataService = null;
    public static EvenementDataService getEvenementDataService() throws Exception {
        if (evenementDataService == null) {
            evenementDataService = new EvenementDataServiceJDBCImpl();
        }
        return evenementDataService;
    }

    private static PersonneDataService personneDataService = null;
    public static PersonneDataService getPersonneDataService() throws Exception {
        if (personneDataService == null) {
            personneDataService = new PersonneDataServiceJDBCImpl();
        }
        return personneDataService;
    }

    private static TimeSlotDataService timeSlotDataService = null;
    public static TimeSlotDataService getTimeSlotService() throws Exception {
        if (timeSlotDataService == null) {
            timeSlotDataService = new TimeSlotDataServiceJDBCImpl();
        }
        return timeSlotDataService;
    }

}
