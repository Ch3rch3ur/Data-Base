package lml.snir.controleacces.physique.data;

import java.util.List;
import java.util.Map;
import lml.snir.persistence.jdbc.AbstractCrudServiceJDBC;
import lml.snir.controleacces.metier.entity.Administrateur;
import lml.snir.controleacces.metier.entity.Personne;

/**
 *
 * @author fanou
 */
final class PersonneDataServiceJDBCImpl<T> extends AbstractCrudServiceJDBC<Personne> implements PersonneDataService {

    PersonneDataServiceJDBCImpl() throws Exception {
        try {
            String query = null;

            switch (super.getDBType()) {
                case MYSQL:
                    query = "CREATE TABLE IF NOT EXISTS `" + super.getEntityName() + "` (\n"
                            + "  `id` int(11) NOT NULL AUTO_INCREMENT,\n"
                            + "  `nom` varchar(32) NOT NULL,\n"
                            + "  `prenom` varchar(32) NOT NULL,\n"
                            + "  `login` varchar(32) DEFAULT NULL,\n"
                            + "  `password` varchar(40) DEFAULT NULL,\n"
                            + "  `discriminant` varchar(1) NOT NULL,\n"
                            + "  PRIMARY KEY (`id`),\n"
                            + "  UNIQUE KEY `id` (`id`),\n"
                            + "  UNIQUE KEY `login` (`login`)\n"
                            + ") ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
                    break;
                case SQLITE:
                    query = "CREATE TABLE IF NOT EXISTS `" + super.getEntityName() + "` (\n"
                            + "  `id` INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                            + "  `nom` varchar(32) NOT NULL,\n"
                            + "  `prenom` varchar(32) NOT NULL,\n"
                            + "  `login` varchar(32) DEFAULT NULL,\n"
                            + "  `password` varchar(40) DEFAULT NULL,\n"
                            + "  `discriminant` varchar(1) NOT NULL\n"
                            + ");";
                    break;
            }
            super.executeQuery(query);

            // create default admin if need
            long count = this.getAdministratorCount();
            if (count == 0) {
                Administrateur adm = new Administrateur();
                adm.setLogin("admin");
                adm.setMdp("admin");
                adm.setNom("admin");
                adm.setPrenom("admin");
                this.add(adm);
            }

        } catch (Exception ex) {
            System.out.println(this.getClass().getSimpleName() + "\n" + super.getDBType() + "\n" + ex);
        }
    }

    @Override
    protected Personne createEntity(Map map) throws Exception {
        Personne personne;

        int id = (int) map.get("id");
        String nom = (String) map.get("nom");
        String prenom = (String) map.get("prenom");
        String login = (String) map.get("login");
        String password = (String) map.get("password");
        String discriminant = (String) map.get("discriminant");

        if ("A".equals(discriminant)) {
            personne = new Administrateur();
            Administrateur a = (Administrateur) personne;
            a.setLogin(login);
            a.setEncodedMdp(password);
        } else {
            personne = new Personne();
        }

        personne.setId(id);
        personne.setNom(nom);
        personne.setPrenom(prenom);

        AttributionDataService attrSrv = PhysiqueDataFactory.getAttributionDataService();

        return personne;
    }

    @Override
    public Personne add(Personne personne) throws Exception {
        String nom = personne.getNom();
        String prenom = personne.getPrenom();
        String login;
        String password;
        String discriminant = "P";
        String query;

        if (personne instanceof Administrateur) {
            Administrateur a = (Administrateur) personne;
            discriminant = "A";
            login = a.getLogin();
            password = a.getMdp();

            query = "INSERT INTO " + super.getEntityName() + " (nom, prenom, login, password, discriminant) VALUES ('"
                    // + personne.getId() + "','"
                    + nom + "','"
                    + prenom + "','"
                    + login + "','"
                    + password + "','"
                    + discriminant + "')";
        } else {
            query = "INSERT INTO " + super.getEntityName() + " (nom, prenom, discriminant) VALUES ('"
                    // + personne.getId() + "','"
                    + nom + "','"
                    + prenom + "','"
                    + discriminant + "')";
        }

        personne.setId(super.executeAdd(query));
        return personne;
    }

    @Override
    public void remove(Personne personne) throws Exception {
        String query = "DELETE FROM " + super.getEntityName() + " WHERE id = '" + personne.getId() + "'";
        super.executeQuery(query);
    }

    @Override
    public void update(Personne personne) throws Exception {
        String discriminant = "P";
        String query = "UPDATE " + super.getEntityName() + " SET discriminant = '"
                + discriminant + "', nom = '"
                + personne.getNom() + "', prenom = '"
                + personne.getPrenom() + "' WHERE id = '" + personne.getId() + "'";

        if (personne instanceof Administrateur) {
            discriminant = "A";
            Administrateur a = (Administrateur) personne;

            query = "UPDATE " + super.getEntityName() + " SET discriminant = '"
                    + discriminant + "', nom = '"
                    + personne.getNom() + "', prenom = '"
                    + personne.getPrenom() + "', login = '"
                    + a.getLogin() + "', password = '"
                    + a.getMdp() + "' WHERE id = '" + personne.getId() + "'";
        }

        super.executeQuery(query);
    }

    @Override
    public Administrateur getByLogin(String login) throws Exception {
        String query = "SELECT * FROM " + super.getEntityName() + " WHERE login = '" + login + "'";
        return (Administrateur) super.getSingleResult(query);
    }

    @Override
    public List<Personne> getByNom(String nom) throws Exception {
        String query = "SELECT * FROM " + super.getEntityName() + "  WHERE nom = '" + nom + "'";
        return super.getResults(query);
    }

    @Override
    public long getAdministratorCount() throws Exception {
        String query = "SELECT COUNT(*) FROM " + super.getEntityName() + "  WHERE discriminant = 'A'";
        return super.getCount(query);
    }

}
