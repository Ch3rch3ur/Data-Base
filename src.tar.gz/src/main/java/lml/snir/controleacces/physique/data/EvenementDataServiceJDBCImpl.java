package lml.snir.controleacces.physique.data;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import lml.snir.persistence.jdbc.AbstractCrudServiceJDBC;
import lml.snir.controleacces.metier.entity.Evenement;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.controleacces.metier.entity.Salle;

/**
 *
 * @author fanou
 */
final class EvenementDataServiceJDBCImpl<T> extends AbstractCrudServiceJDBC<Evenement> implements EvenementDataService {

    private final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    EvenementDataServiceJDBCImpl() throws Exception {
        try {
            String query = null;

            switch (super.getDBType()) {
                case MYSQL:
                    query = "CREATE TABLE IF NOT EXISTS `" + super.getEntityName() + "` (\n"
                            + "  `id` int(11) NOT NULL AUTO_INCREMENT,\n"
                            + "  `idPersonne` int(11) NOT NULL,\n"
                            + "  `idSalle` int(11) NOT NULL,\n"
                            + "  `date` datetime NOT NULL,\n"
                            + "  `autorise` tinyint(1) NOT NULL,\n"
                            + "  PRIMARY KEY (`id`)\n"
                            + ") ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;";
                    break;
                case SQLITE:
                    query = "CREATE TABLE IF NOT EXISTS `" + super.getEntityName() + "` (\n"
                            + "  `id` INTEGER PRIMARY KEY AUTOINCREMENT,\n" // int(11) NOT NULL
                            + "  `idPersonne` int(11) NOT NULL,\n"
                            + "  `idSalle` int(11) NOT NULL,\n"
                            + "  `date` datetime NOT NULL,\n"
                            + "  `autorise` tinyint(1) NOT NULL\n"
                            //+ "  PRIMARY KEY (`id`)\n"
                            + ");";
                    break;
            }
            super.executeQuery(query);

        } catch (Exception ex) {
            System.out.println(this.getClass().getSimpleName() + "\n" + super.getDBType() + "\n" + ex);
        }
    }

    @Override
    protected Evenement createEntity(Map map) throws Exception {
        Evenement event;

        long id = (int) map.get("id");
        long idPersonne = (int) map.get("idPersonne");
        long idSalle = (int) map.get("idSalle");
        boolean autorise = ((int) map.get("autorise") == 1);
        //Timestamp stamp = rs.getTimestamp("date");
        String stamp = (String) map.get("date");
        Date date = this.dateFormat.parse(stamp); //new Date(stamp.getTime());

        Personne personne = PhysiqueDataFactory.getPersonneDataService().getById(idPersonne);
        Salle salle = PhysiqueDataFactory.getSalleDataService().getById(idSalle);

        event = new Evenement();
        event.setId(id);
        event.setAutorise(autorise);
        event.setDate(date);
        event.setPersonne(personne);
        event.setSalle(salle);

        return event;
    }

    @Override
    public Evenement add(Evenement evenement) throws Exception {
        String strAutorise = "0";
        if (evenement.isAutorise()) {
            strAutorise = "1";
        }

        String query = "INSERT INTO " + super.getEntityName() + " (date, idPersonne, idSalle, autorise) VALUES ('"
                //+ evenement.getId() + "','"
                + dateFormat.format(evenement.getDate()) + "','"
                + evenement.getPersonne().getId() + "','"
                + evenement.getSalle().getId() + "','"
                + strAutorise + "')";

        evenement.setId(super.executeAdd(query));
        return evenement;
    }

    @Override
    public void remove(Evenement evenement) throws Exception {
        String query = "DELETE FROM " + super.getEntityName() + " WHERE id = '" + evenement.getId() + "'";
        super.executeQuery(query);
    }

    @Override
    public void update(Evenement evenement) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // A VERIFIER
    @Override
    public List<Evenement> getByJour(Date jour) throws Exception {
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String query = "SELECT * FROM " + super.getEntityName() + " WHERE date LIKE '%" + sdf.format(jour) + "%'";
        return super.getResults(query);
    }

    @Override
    public List<Evenement> getBySalle(Salle salle) throws Exception {
        String query = "SELECT * FROM " + super.getEntityName() + " WHERE idSalle = '" + salle.getId() + "'";
        return super.getResults(query);
    }

}
