package lml.snir.controleacces.physique.data;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import lml.snir.persistence.jdbc.AbstractCrudServiceJDBC;
import lml.snir.controleacces.metier.entity.Salle;

/**
 *
 * @author fanou
 */
final class SalleDataServiceJDBCImpl<T> extends AbstractCrudServiceJDBC<Salle> implements SalleDataService {

    SalleDataServiceJDBCImpl() throws Exception {
        try {
            String query = "CREATE TABLE IF NOT EXISTS `" + super.getEntityName() + "` (\n"
                            + "  `id` INTEGER PRIMARY KEY,\n"
                            + "  `protege` tinyint(1) NOT NULL\n"
                            + ");";
            
            super.executeQuery(query);

        } catch (Exception ex) {
            System.out.println(this.getClass().getSimpleName() + "\n" + super.getDBType() + "\n" + ex);
        }
    }

    @Override
    protected Salle createEntity(Map map) throws Exception {
        Salle salle;

        long id = (int) map.get("id");
        Object protege = map.get("protege");

        salle = new Salle();
        salle.setId(id);
        if (protege instanceof Boolean) {
            salle.setProtege((Boolean) protege);
        } else {
            salle.setProtege((int)protege == 1);
        }

        return salle;
    }

    @Override
    public Salle add(Salle salle) throws Exception {
        String protec = "0";
        if (salle.isProtege()) {
            protec = "1";
        }
        String query = "INSERT INTO " + super.getEntityName() + " (id, protege) VALUES ('"
                + salle.getId() + "','"
                + protec + "')";
        salle.setId(super.executeAdd(query));

        return salle;
    }

    @Override
    public void remove(Salle salle) throws Exception {
        String query = "DELETE FROM " + super.getEntityName() + " WHERE id = '" + salle.getId() + "'";
        super.executeQuery(query);
    }

    @Override
    public void update(Salle salle) throws Exception {
        String protec = "0";
        if (salle.isProtege()) {
            protec = "1";
        }
        String query = "UPDATE " + super.getEntityName() + " SET id = '"
                + salle.getId() + "', protege = '"
                + protec
                + "' WHERE id = '" + salle.getId() + "'";
        super.executeQuery(query);
    }

    @Override
    public List<Salle> getByProtege(boolean protege) throws Exception {
        String protec = "0";
        if (protege) {
            protec = "1";
        }
        String query = "SELECT * FROM " + super.getEntityName() + " WHERE protege = '" + protec + "'";

        return super.getResults(query);
    }
}
