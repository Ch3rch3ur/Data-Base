package lml.snir.controleacces.converter;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Badge;

/**
 *
 * @author jupiter
 */

@FacesConverter(forClass = Badge.class)
public class BadgeConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        Badge badge = null;

        if (value == null || value.length() == 0) {
            return null;
        }

        try {
            badge = MetierFactory.getBadgeService().getByContenu(value);
        } catch (Exception ex) {
            Logger.getLogger(BadgeConverter.class.getName()).log(Level.SEVERE, null, ex);
        }

        return badge;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        Badge badge = (Badge) value;
        
        return badge.getContenu();
    }

}
