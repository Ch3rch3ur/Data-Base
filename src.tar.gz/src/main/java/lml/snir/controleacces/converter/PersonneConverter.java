/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lml.snir.controleacces.converter;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Personne;

/**
 *
 * @author kevin
 */
@FacesConverter(forClass = Personne.class)
public class PersonneConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String string) {
        Personne personne = null;
        
        if (string == null || string.length() == 0) {
            return null;
        }
        
        try {
            personne = MetierFactory.getPersonneService().getById((long) Integer.parseInt(string));
        } catch (Exception ex) {
            Logger.getLogger(PersonneConverter.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return personne;
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object o) {
        Personne personne = (Personne) o;
        
        return String.valueOf(personne.getId());
    }
    
}
