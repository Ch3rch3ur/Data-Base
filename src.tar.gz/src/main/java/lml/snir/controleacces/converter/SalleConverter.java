/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lml.snir.controleacces.converter;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Salle;

/**
 *
 * @author kevin
 */
@FacesConverter(forClass = Salle.class)
public class SalleConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String string) {
        Salle salle = null;
        
        if (string == null || string.length() == 0) {
            return null;
        }
        
        try {
            // salle = MetierFactory.getSalleService().getById((long) Integer.parseInt(string.split(" : ")[0]));
            
            String[] l = string.split(" ");
            
            salle = MetierFactory.getSalleService().getById(Long.parseLong(l[l.length -1]));
            
        } catch (Exception ex) {
            Logger.getLogger(SalleConverter.class.getName()).log(Level.SEVERE, null, ex);
        }
         
        return salle;
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object o) {
        Salle salle = (Salle) o;
        
        return salle.toString();
    }
    
}
