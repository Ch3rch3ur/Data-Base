package lml.snir.controleacces.client;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Day;
import lml.snir.controleacces.metier.entity.TimeSlot;

/**
 *
 * @author jupiter
 */
@ManagedBean
@ViewScoped
public class TimeSlotServiceBean implements Serializable {

    public TimeSlotServiceBean() {
        try {
            ClientFactory.timeSlotSrv = MetierFactory.getTimeSlotService();
        } catch (Exception ex) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", ex.getMessage()));
        }
    }

    private Day beginday;
    private int beginhour;
    private int beginminutes;
    private Day endday;
    private int endhour;
    private int endminutes;

    private TimeSlot timeSlot;

    public List<TimeSlot> getTimeSlots() throws Exception {
        return ClientFactory.timeSlotSrv.getAll();
    }

    public void ajouterTimeSlot() throws Exception {
        if ((beginday != null) && (beginhour >= 0) && (beginminutes >= 0) && (endday != null) && (endhour >= 0) && (endminutes >= 0) && (timeSlot == null)) {
            TimeSlot t = new TimeSlot(beginday, beginhour, beginminutes, endday, endhour, endminutes);
            ClientFactory.timeSlotSrv.add(t);

            beginday = null;
            beginhour = 0;
            beginminutes = 0;
            endday = null;
            endhour = 0;
            endminutes = 0;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez remplir tous les champs"));
        }
    }

    public void modifierTimeSlot(TimeSlot t) throws Exception {
        if (null != t) {
            this.timeSlot = t;
            this.beginday = t.getBeginDay();
            this.beginhour = t.getBeginHour();
            this.beginminutes = t.getBeginMinutes();
            this.endday = t.getEndDay();
            this.endhour = t.getEndHour();
            this.endminutes = t.getEndMinutes();
        }
    }

    public void supprimerTimeSlot(TimeSlot t) throws Exception {
        if (null != t) {
            ClientFactory.timeSlotSrv.remove(t);
        }
    }

    public void updateTimeSlot() throws Exception {
        if ((beginday != null) && (beginhour >= 0) && (beginminutes >= 0) && (endday != null) && (endhour >= 0) && (endminutes >= 0) && (timeSlot != null)) {
            //TimeSlot t = new TimeSlot(timeSlot.getId(), beginday, beginhour, beginminutes, endday, endhour, endminutes);
            TimeSlot t = new TimeSlot(beginday, beginhour, beginminutes, endday, endhour, endminutes);
            t.setId(timeSlot.getId());
            
            ClientFactory.timeSlotSrv.update(t);

            this.beginday = null;
            this.beginhour = 0;
            this.beginminutes = 0;
            this.endday = null;
            this.endhour = 0;
            this.endminutes = 0;
            this.timeSlot = null;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez remplir tous les champs"));
        }
    }

    public TimeSlot getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(TimeSlot timeSlot) {
        this.timeSlot = timeSlot;
    }

    public Day getBeginday() {
        return beginday;
    }

    public void setBeginday(Day beginday) {
        this.beginday = beginday;
    }

    public int getBeginhour() {
        return beginhour;
    }

    public void setBeginhour(int beginhour) {
        this.beginhour = beginhour;
    }

    public int getBeginminutes() {
        return beginminutes;
    }

    public void setBeginminutes(int beginminutes) {
        this.beginminutes = beginminutes;
    }

    public Day getEndday() {
        return endday;
    }

    public void setEndday(Day endday) {
        this.endday = endday;
    }

    public int getEndhour() {
        return endhour;
    }

    public void setEndhour(int endhour) {
        this.endhour = endhour;
    }

    public int getEndminutes() {
        return endminutes;
    }

    public void setEndminutes(int endminutes) {
        this.endminutes = endminutes;
    }

    public List<Day> getDays() throws Exception {
        return Arrays.asList(Day.values());
    }

}
