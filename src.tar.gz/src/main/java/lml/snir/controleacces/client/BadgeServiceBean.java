package lml.snir.controleacces.client;

import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Badge;

/**
 *
 * @author jupiter
 */
@ManagedBean
@ViewScoped
public class BadgeServiceBean implements Serializable {
    public  BadgeServiceBean() {
        try {
            ClientFactory.badgeSrv = MetierFactory.getBadgeService();        } catch (Exception ex) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", ex.getMessage()));
        }
    }

    private String contenu; // Contenu récupéré deupios l'ihm

    private Badge badge; // Badge récupéré depuis l'ihm

    public List<Badge> getBadges() throws Exception {
        return ClientFactory.badgeSrv.getAll();
    }

    public void ajouterBadge() throws Exception {
        if ((contenu.length() > 0) && (badge == null)) {
            Badge b = new Badge();
            b.setContenu(contenu);
            ClientFactory.badgeSrv.add(b);

            contenu = null;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez entrer le contenu et séléctionner un badge"));
        }
    }

    public void modifierBadge(Badge b) throws Exception {
        if (null != b) {
            this.badge = b;
            this.contenu = b.getContenu();
        }
    }

    public void updateBadge() throws Exception {
        if ((contenu.length() > 0) && (badge != null)) {
            Badge b = new Badge();
            b.setContenu(contenu);
            b.setId(badge.getId());

            ClientFactory.badgeSrv.update(b);

            this.contenu = null;
            this.badge = null;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez entrer le contenu et séléctionner un badge"));
        }
    }

    public void supprimerBadge(Badge b) throws Exception {
        if (null != b) {
            ClientFactory.badgeSrv.remove(b);
        }
    }

    public Badge getBadge() {
        return badge;
    }

    public void setBadge(Badge badge) {
        this.badge = badge;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

}
