package lml.snir.controleacces.client;

import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Administrateur;
import lml.snir.controleacces.metier.entity.Personne;

/**
 *
 * @author jupiter
 */
@ManagedBean
@ViewScoped
public class PersonneServiceBean implements Serializable {

    public  PersonneServiceBean() {
        try {
            ClientFactory.personneSrv = MetierFactory.getPersonneService();
        } catch (Exception ex) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", ex.getMessage()));
        }
    }

    private String admin;       //
    private String nom;         //
    private String prenom;      //  Attributs à récupérer dans l'ihm
    private String newLogin;    //
    private String password;    //

    private List<Personne> personnes;

    private Personne personne;
    private Administrateur administrateur;

    int i = 0, j = 0;

    public List<Personne> getPersonnes() throws Exception {
        this.i = 0;
        this.j = 0;
        return this.personnes = ClientFactory.personneSrv.getAll();
    }

    public String getDiscriminant() throws Exception {
        if (j == personnes.size()) {
            j = 0;
        }

        String discriminant = "Personne";

        if ((this.personnes.get(j)) instanceof Administrateur) {
            discriminant = "Administrateur";
        }

        j++;

        return discriminant;
    }

    public String getLogin() throws Exception {
        if (i == personnes.size()) {
            i = 0;
        }

        Personne p;
        String login = null;

        if ((p = this.personnes.get(i)) instanceof Administrateur) {
            Administrateur a = (Administrateur) p;
            login = a.getLogin();
        }

        i++;

        return login;
    }

    public void ajouterPersonne() throws Exception {
        if ((nom.length() > 0) && (prenom.length() > 0) && (personne == null) && (administrateur == null) && (admin != null)) {
            if (admin.equals("Administrateur")) {
                if ((newLogin.length() > 0) && (password.length() > 0)) {
                    Administrateur a = new Administrateur(); //newLogin, password, nom, prenom);
                    a.setLogin(newLogin);
                    a.setMdp(password);
                    a.setNom(nom);
                    a.setPrenom(prenom);
                    ClientFactory.personneSrv.add(a);
                } else {
                    FacesContext context = FacesContext.getCurrentInstance();
                    context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez remplir tous les champs"));
                }
            } else {
                Personne p = new Personne(); //nom, prenom);
                p.setNom(nom);
                p.setPrenom(prenom);

                ClientFactory.personneSrv.add(p);
            }
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez remplir tous les champs"));
        }
        this.nom = "";
        this.prenom = "";
        this.newLogin = "";
        this.password = "";
    }

    public void supprimerPersonne(Personne p) throws Exception {
        if (null != p) {
            ClientFactory.personneSrv.remove(p);
        }
        i = 0;
        j = 0;
    }

    public void modifierPersonne(Personne p) throws Exception {
        if (null != p) {
            this.personne = p;
            this.nom = p.getNom();
            this.prenom = p.getPrenom();
            if (p instanceof Administrateur) {
                this.admin = "Administrateur";
                this.administrateur = (Administrateur) p;
                this.newLogin = this.administrateur.getLogin();
            } else {
                this.admin = "Personne";
            }
        }
    }

    public void updatePersonne() throws Exception {
        if ((nom.length() > 0) && (prenom.length() > 0) && (admin != null)) {
            if (admin.equals("Personne")) {

                Personne p = new Personne(); //nom, prenom);
                p.setNom(nom);
                p.setPrenom(prenom);
                p.setId(this.personne.getId());
                //Personne p = new Personne(this.personne.getId(), nom, prenom);

                if (this.personne instanceof Administrateur) {
                    ClientFactory.personneSrv.remove(this.personne);
                    ClientFactory.personneSrv.add(p);
                } else {
                    ClientFactory.personneSrv.update(p);
                }
            } else {
                if ((newLogin.length() > 0) && (password.length() > 0)) {
                    //Administrateur a = new Administrateur(newLogin, password, this.personne.getId(), nom, prenom);
                    Administrateur a = new Administrateur(); //newLogin, password, nom, prenom);
                    a.setLogin(newLogin);
                    a.setMdp(password);
                    a.setNom(nom);
                    a.setPrenom(prenom);
                    a.setId(this.personne.getId());

                    if (this.personne instanceof Administrateur) {
                        ClientFactory.personneSrv.update(a);
                    } else {
                        ClientFactory.personneSrv.remove(this.personne);
                        ClientFactory.personneSrv.add(a);
                    }
                } else {
                    FacesContext context = FacesContext.getCurrentInstance();
                    context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez remplir tous les champs"));
                }
            }
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez remplir tous les champs"));
        }

        this.nom = null;
        this.prenom = null;
        this.newLogin = null;
        this.admin = null;
        this.password = null;
        this.personne = null;
        this.administrateur = null;
        i = 0;
        j = 0;
    }

    public Personne getPersonne() {
        return personne;
    }

    public void setPersonne(Personne personne) {
        this.personne = personne;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Administrateur getAdministrateur() {
        return administrateur;
    }

    public void setAdministrateur(Administrateur administrateur) {
        this.administrateur = administrateur;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public String getNewLogin() {
        return newLogin;
    }

    public void setNewLogin(String newLogin) {
        this.newLogin = newLogin;
    }

}
