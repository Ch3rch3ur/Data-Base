package lml.snir.controleacces.client;

import java.io.Serializable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Attribution;
import lml.snir.controleacces.metier.entity.Badge;
import lml.snir.controleacces.metier.entity.Personne;

/**
 *
 * @author jupiter
 */
@ManagedBean
@ViewScoped
public class AttributionServiceBean implements Serializable {

    public  AttributionServiceBean() {
        try {
            ClientFactory.attributionSrv = MetierFactory.getAttributionService();
        } catch (Exception ex) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", ex.getMessage()));
        }
    }
    
    private Badge badge; // Badge récupéré depuis l'ihm
    private Personne personne; // Personne récupérée depuis l'ihm

    private Attribution attribution; // Attribution à modifier

    public List<Attribution> getAttributions() throws Exception {
        return ClientFactory.attributionSrv.getAll();
    }
    
    public void setAttributions(List<Attribution> attrs) throws Exception {
        // do nothing
    }

    public void ajouterAttribution() {
        if ((badge != null) && (personne != null) && (attribution == null)) {
            Attribution a = new Attribution();
            a.setBadge(badge);
            a.setPersonne(personne);
            try {
                ClientFactory.attributionSrv.add(a);
            } catch (Exception ex) {
                FacesContext context = FacesContext.getCurrentInstance();
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", ex.getMessage()));
            }

            badge = null;
            personne = null;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez séléctionner un badge et une personne"));
        }
    }

    public void editerAttribution(Attribution a) throws Exception {
        if (null != a) {
            this.attribution = a;
            this.badge = a.getBadge();
            this.personne = a.getPersonne();
        }
    }

    public void updateAttribution() throws Exception {
        if ((null != badge) && (null != personne) && (attribution != null)) {
            Attribution a = new Attribution();
            a.setBadge(badge);
            a.setPersonne(personne);
            a.setId(attribution.getId());
            ClientFactory.attributionSrv.update(a);

            this.badge = null;
            this.personne = null;
            this.attribution = null;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez séléctionner un badge et une personne"));
        }
    }

    public void supprimerAttribution(Attribution a) throws Exception {
        if (null != a) {
            ClientFactory.attributionSrv.remove(a);
        }
    }

    public List<Badge> getBadges() throws Exception {
        return MetierFactory.getBadgeService().getAll();
    }

    public List<Personne> getPersonnes() throws Exception {
        return MetierFactory.getPersonneService().getAll();
    }

    public Badge getBadge() {
        return badge;
    }

    public void setBadge(Badge badge) {
        this.badge = badge;
    }

    public Personne getPersonne() {
        return personne;
    }

    public void setPersonne(Personne personne) {
        this.personne = personne;
    }

    public Attribution getAttribution() {
        return attribution;
    }

    public void setAttribution(Attribution attribution) {
        this.attribution = attribution;
    }

}
