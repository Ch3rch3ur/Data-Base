/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lml.snir.controleacces.client;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.fonctionnel.AutorisationRPCService;
import lml.snir.jsonrpc.core.transport.Transporter;
import lml.snir.jsonrpc.core.transport.tcp.TcpServerTransporter;


@ManagedBean
@ApplicationScoped
public class RPCServerBean {
    private String state;
    
    public RPCServerBean() {
        System.out.println("lml.snir.controleacces.client.RPCServerBean.<init>()");
        try {
            // ATTENTION ON DOIT ABSOLUMENT ACCEDER A LA BDD EN PREMIER DANS LEE CONTEXTE SERVEUR WEB !
            long count = MetierFactory.getPersonneService().getCount();
            
            // init transporter
            state = "befor init";
            Map<String, Object> services = new HashMap<>();
            services.put(AutorisationRPCService.class.getName(), MetierFactory.getAutorisationRPCService());
            Transporter transporter = new TcpServerTransporter(9999, services); //new SerialServerTransporter(serial, services);
            transporter.open();
            
            System.out.println("wait");
            state = "init OK waitting";
        } catch (Exception ex) {
            state =  "error : " + ex.getMessage();
            Logger.getLogger(RPCServerBean.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("lml.snir.controleacces.client.RPCServerBean.<init>()");
            System.err.println(ex.getMessage());
        }
    }
    
    public String getState() {
        return this.state;
    }
    
}
