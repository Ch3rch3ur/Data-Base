package lml.snir.controleacces.client;

import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Salle;

/**
 *
 * @author jupiter
 */
@ManagedBean
@ViewScoped
public class SalleServiceBean implements Serializable {
    public  SalleServiceBean() {
        try {
            ClientFactory.salleSrv = MetierFactory.getSalleService();
        } catch (Exception ex) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", ex.getMessage()));
        }
    }

    private int numero;         // Attributs à récupérer dans l'ihm
    private String protege;    //

    private Salle salle;        // Salle à modifier

    public List<Salle> getSalles() throws Exception {
        return ClientFactory.salleSrv.getAll();
    }

    public void ajouterSalle() throws Exception {
        if ((protege != null) && (salle == null)) {
            Salle s = new Salle(); //numero, protege.equals("Protege"));
            s.setId(numero);
            s.setProtege(protege.equals("Protege"));

            ClientFactory.salleSrv.add(s);

            numero = 0;
            protege = null;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez entrer le numéro de la salle et préciser si protégé ou non"));
        }
    }

    public void modifierSalle(Salle s) throws Exception {
        this.protege = "NonProtege";

        if (null != s) {
            this.salle = s;
            this.numero = (int) s.getId();

            if (s.isProtege()) {
                this.protege = "Protege";
            }
        }
    }

    public void updateSalle() throws Exception {
        if ((protege != null) && (null != salle)) {
            //Salle s = new Salle(salle.getId(), numero, protege.equals("Protege"));
            Salle s = new Salle(); //numero, protege.equals("Protege"));
            s.setId(salle.getId());
            s.setProtege(protege.equals("Protege"));

            ClientFactory.salleSrv.update(s);
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez entrer le numéro de la salle et préciser si protégé ou non"));
        }

        this.numero = 0;
        this.protege = null;
        this.salle = null;
    }

    public void supprimerSalle(Salle s) throws Exception {
        if (null != s) {
            ClientFactory.salleSrv.remove(s);
        }
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getProtege() {
        return protege;
    }

    public void setProtege(String protege) {
        this.protege = protege;
    }

}
