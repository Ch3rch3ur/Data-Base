package lml.snir.controleacces.client;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import lml.snir.controleacces.metier.entity.Administrateur;

/**
 *
 * @author jupiter
 */
@ManagedBean
@SessionScoped
public class NavigatorBean implements Serializable {

    private Administrateur adm;

    private String content = "/login.xhtml";

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    
    public void delogg() {
        this.adm = null;
        this.content = "/login.xhtml";
    }

    private void changeView(String view) {
        if (adm != null) {
            this.content = view;
        }
    }

    public void attributionService() {
        this.changeView("/Attribution/attributionService.xhtml");
    }

    public void modifierAttribution() {
        this.changeView("/Attribution/modifierAttribution.xhtml");
    }

    public void autorisationService() {
        this.changeView("/Autorisation/autorisationService.xhtml");
    }

    public void modifierAutorisation() {
        this.changeView("/Autorisation/modifierAutorisation.xhtml");
    }

    public void badgeService() {
        this.changeView("/Badge/badgeService.xhtml");
    }

    public void modifierBadge() {
        this.changeView("/Badge/modifierBadge.xhtml");
    }

    public void evenementService() {
        this.changeView("/Evenement/evenementService.xhtml");
    }

    public void personneService() {
        this.changeView("/Personne/personneService.xhtml");
    }

    public void modifierPersonne() {
        this.changeView("/Personne/modifierPersonne.xhtml");
    }

    public void salleService() {
        this.changeView("/Salle/salleService.xhtml");
    }

    public void modifierSalle() {
        this.changeView("/Salle/modifierSalle.xhtml");
    }

    public void timeSlotService() {
        this.changeView("/TimeSlot/timeSlotService.xhtml");
    }

    public void modifierTimeSlot() {
        this.changeView("/TimeSlot/modifierTimeSlot.xhtml");
    }

    /**
     * @return the adm
     */
    public Administrateur getAdm() {
        return adm;
    }

    /**
     * @param adm the adm to set
     */
    public void setAdm(Administrateur adm) {
        this.adm = adm;
    }

}
