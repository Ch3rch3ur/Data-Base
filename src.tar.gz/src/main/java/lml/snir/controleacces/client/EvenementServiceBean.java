package lml.snir.controleacces.client;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Evenement;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.controleacces.metier.entity.Salle;

/**
 *
 * @author jupiter
 */
@ManagedBean
@ViewScoped
public class EvenementServiceBean implements Serializable {
    public  EvenementServiceBean() {
        try {
            ClientFactory.evenementSrv = MetierFactory.getEvenementService();
        } catch (Exception ex) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", ex.getMessage()));
        }
    }
    
    private Personne personne;  //
    private Salle salle;        // Attributs à récuperer dans l'ihm
    private Date date;          //
    private boolean autorise;   //
    
    private Evenement evenement; // evenement à modifier
    
    public List<Evenement> getEvenements() throws Exception {
        return ClientFactory.evenementSrv.getAll();
    }
    
    public void supprimerEvenement(Evenement e) throws Exception {
        if (null != e) {
            ClientFactory.evenementSrv.remove(e);
        }
    }
    
    public Evenement getEvenement() {
        return evenement;
    }

    public void setEvenement(Evenement evenement) {
        this.evenement = evenement;
    }

    public Personne getPersonne() {
        return personne;
    }

    public void setPersonne(Personne personne) {
        this.personne = personne;
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isAutorise() {
        return autorise;
    }

    public void setAutorise(boolean autorise) {
        this.autorise = autorise;
    }
    
}
