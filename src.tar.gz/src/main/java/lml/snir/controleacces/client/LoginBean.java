package lml.snir.controleacces.client;

import java.io.Serializable;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Administrateur;

/**
 *
 * @author kevin
 */
@ManagedBean
@ViewScoped
public class LoginBean implements Serializable {

    private String login;       // Attributs à récupérer
    private String password;    // dans l'ihm

    public String connexion() throws Exception {
        Administrateur admin = null;
        if (null != (admin = MetierFactory.getPersonneService().getByLogin(this.login))) {
            if (admin.isValid(password)) {
                FacesContext context = FacesContext.getCurrentInstance();
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Information", "Connexion réussie"));
                Application application = context.getApplication();
                NavigatorBean navigBean = application.evaluateExpressionGet(context, "#{navigatorBean}", NavigatorBean.class);
                navigBean.setAdm(admin);
                navigBean.setContent("/Personne/personneService.xhtml");
                return "/index.xhtml";
            } else {
                FacesContext context = FacesContext.getCurrentInstance();
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Echec de connexion\nMauvais identifiant ou mot de passe"));

                return "";
            }
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Echec de connexion\nMauvais identifiant ou mot de passe"));

            return "";
        }
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
