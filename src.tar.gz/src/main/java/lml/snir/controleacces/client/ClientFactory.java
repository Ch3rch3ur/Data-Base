package lml.snir.controleacces.client;

import lml.snir.controleacces.metier.transactionnel.AttributionService;
import lml.snir.controleacces.metier.transactionnel.AutorisationService;
import lml.snir.controleacces.metier.transactionnel.BadgeService;
import lml.snir.controleacces.metier.transactionnel.EvenementService;
import lml.snir.controleacces.metier.transactionnel.PersonneService;
import lml.snir.controleacces.metier.transactionnel.SalleService;
import lml.snir.controleacces.metier.transactionnel.TimeSlotService;

/**
 *
 * @author fanou
 */
public class ClientFactory {
    private ClientFactory() {}
    
    static AttributionService attributionSrv;
    static AutorisationService autorisationSrv;
    static BadgeService badgeSrv;
    static EvenementService evenementSrv;
    static PersonneService personneSrv;
    static SalleService salleSrv;
    static TimeSlotService timeSlotSrv;
}
