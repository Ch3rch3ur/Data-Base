package lml.snir.controleacces.client;

import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Autorisation;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.controleacces.metier.entity.Salle;
import lml.snir.controleacces.metier.entity.TimeSlot;

/**
 *
 * @author jupiter
 */
@ManagedBean
@ViewScoped
public class AutorisationServiceBean implements Serializable {
    public  AutorisationServiceBean() {
        try {
            ClientFactory.autorisationSrv = MetierFactory.getAutorisationService();
        } catch (Exception ex) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", ex.getMessage()));
        }
    }
    
    private Salle salle;         //
    private Personne personne;   // Attributs à récuperer dans l'ihm
    private TimeSlot timeslot;   //

    private Autorisation autorisation; // Autorisation à modifier

    public void ajouterAutorisation() throws Exception {
        if ((salle != null) && (personne != null) && (timeslot != null) && (autorisation == null)) {
            Autorisation a = new Autorisation();
            a.setPersonne(personne);
            a.setPlageHoraire(timeslot);
            a.setSalle(salle);
            ClientFactory.autorisationSrv.add(a);

            salle = null;
            personne = null;
            timeslot = null;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez séléctionner une salle, une personne et une plage horaire"));
        }
    }

    public void modifierAutorisation(Autorisation autorisation) throws Exception {
        if (null != autorisation) {
            this.autorisation = autorisation;
            this.salle = autorisation.getSalle();
            this.personne = autorisation.getPersonne();
            this.timeslot = autorisation.getPlageHoraire();
        }
    }

    public void supprimerAutorisation(Autorisation autorisation) throws Exception {
        if (null != autorisation) {
            ClientFactory.autorisationSrv.remove(autorisation);
        }
    }

    public void updateAutorisation() throws Exception {
        if ((salle != null) && (personne != null) && (timeslot != null) && (autorisation != null)) {
            Autorisation a = new Autorisation();
            a.setPersonne(personne);
            a.setId(autorisation.getId());
            ClientFactory.autorisationSrv.update(a);

            this.salle = null;
            this.personne = null;
            this.timeslot = null;
            this.autorisation = null;
        } else {
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erreur", "Veuillez séléctionner une salle, une personne et une plage horaire"));
        }
    }

    public List<Autorisation> getAutorisations() throws Exception {
        return ClientFactory.autorisationSrv.getAll();
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public Personne getPersonne() {
        return personne;
    }

    public void setPersonne(Personne personne) {
        this.personne = personne;
    }

    public TimeSlot getTimeslot() {
        return timeslot;
    }

    public void setTimeslot(TimeSlot timeslot) {
        this.timeslot = timeslot;
    }

    public Autorisation getAutorisation() {
        return autorisation;
    }

    public void setAutorisation(Autorisation autorisation) {
        this.autorisation = autorisation;
    }

    public List<Salle> getSalles() throws Exception {
        return MetierFactory.getSalleService().getAll();
    }

    public List<Personne> getPersonnes() throws Exception {
        return MetierFactory.getPersonneService().getAll();
    }

    public List<TimeSlot> getTimeslots() throws Exception {
        return MetierFactory.getTimeSlotService().getAll();
    }

}
