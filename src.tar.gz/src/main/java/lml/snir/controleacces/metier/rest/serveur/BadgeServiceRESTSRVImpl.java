package lml.snir.controleacces.metier.rest.serveur;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import lml.snir.controleacces.metier.transactionnel.BadgeService;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Badge;
import lml.snir.rest.server.RestException;

@Path("/BadgeService")
@Consumes("application/json")
@Produces("application/json")
public class BadgeServiceRESTSRVImpl {

    private final BadgeService badgeService = MetierFactory.getBadgeService();
    public BadgeServiceRESTSRVImpl() throws Exception {
        
    }

//    @GET
//    @Path("/getByPlageHoraire/{idTimeSlot}")
//    public List<Badge> getByPlageHoraire(@PathParam("idTimeSlot") long  idTimeSlot) throws Exception{
//        TimeSlot ts = MetierFactory.getTimeSlotService().getById(idTimeSlot);
//        return this.badgeService.getByPlageHoraire(ts);
//    }
    @POST
    @Path("/")
    public Badge add(Badge t) throws Exception {
        try {
            return this.badgeService.add(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @DELETE
    @Path("/")
    public void remove(Badge t) throws Exception {
        try {
            this.badgeService.remove(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @PUT
    @Path("/")
    public void update(Badge t) throws Exception {
        try {
            this.badgeService.update(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/Count")
    public long getCount() throws Exception {
        try {
            return this.badgeService.getCount();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/")
    public List<Badge> getAll() throws Exception {
        try {
            return this.badgeService.getAll();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{begin}/{count}")
    public List<Badge> getAll(@PathParam("begin") int begin, @PathParam("count") int count) throws Exception {
        try {
            return this.badgeService.getAll(begin, count);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{id}")
    public Badge getById(Long id) throws Exception {
        try {
            return this.badgeService.getById(id);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }
}
