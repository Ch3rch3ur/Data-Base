/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lml.snir.controleacces.metier.rest.serveur;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.transactionnel.PersonneService;
import lml.snir.controleacces.metier.entity.Administrateur;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.rest.server.RestException;

@Path("/PersonneService")
@Consumes("application/json")
@Produces("application/json")
public class PersonneServiceRESTSRVImpl {

    private final PersonneService personneService = MetierFactory.getPersonneService();
    public PersonneServiceRESTSRVImpl() throws Exception {
        
    }

    @GET
    @Path("/getByLogin/{login}")
    public Administrateur getByLogin(@PathParam("login") String login) throws Exception {
        try {
            Administrateur adm = this.personneService.getByLogin(login);
            return adm;
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/getByNom/{nom}")
    public List<Personne> getByNom(@PathParam("nom") String nom) throws Exception {
        try {
            return this.personneService.getByNom(nom);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @POST
    @Path("/")
    public Personne add(Personne t) throws Exception {
        try {
            return this.personneService.add(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @DELETE
    @Path("/")
    public void remove(Personne t) throws Exception {
        try {
            this.personneService.remove(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @PUT
    @Path("/")
    public void update(Personne t) throws Exception {
        try {
            this.personneService.update(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/Count")
    public long getCount() throws Exception {
        try {
            return this.personneService.getCount();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/")
    public List<Personne> getAll() throws Exception {
        try {
            return this.personneService.getAll();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{begin}/{count}")
    public List<Personne> getAll(@PathParam("begin") int begin, @PathParam("count") int count) throws Exception {
        try {
            return this.personneService.getAll(begin, count);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{id}")
    public Personne getById(@PathParam("id") Long id) throws Exception {
        try {
            return this.personneService.getById(id);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }
}
