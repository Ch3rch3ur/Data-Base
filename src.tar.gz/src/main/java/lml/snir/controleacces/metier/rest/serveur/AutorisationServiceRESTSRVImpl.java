package lml.snir.controleacces.metier.rest.serveur;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import lml.snir.controleacces.metier.transactionnel.AutorisationService;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Autorisation;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.controleacces.metier.entity.Salle;
import lml.snir.controleacces.metier.entity.TimeSlot;
import lml.snir.rest.server.RestException;

@Path("/AutorisationService")
@Consumes("application/json")
@Produces("application/json")
public class AutorisationServiceRESTSRVImpl {

    private final AutorisationService autorisationService = MetierFactory.getAutorisationService();
    public AutorisationServiceRESTSRVImpl() throws Exception {
        
    }
    
    public List<Autorisation> getBySalle(long idSalle) throws Exception {
        try {
            Salle salle = MetierFactory.getSalleService().getById(idSalle);
            return this.autorisationService.getBySalle(salle);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    public List<Autorisation> getByPersonne(long idPersonne) throws Exception {
        try {
            Personne personne = MetierFactory.getPersonneService().getById(idPersonne);
            return this.autorisationService.getByPersonne(personne);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    public List<Autorisation> getByPlageHoraire(long idTimeSlot) throws Exception {
        try {
            TimeSlot ts = MetierFactory.getTimeSlotService().getById(idTimeSlot);
            return this.autorisationService.getByPlageHoraire(ts);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    public List<Autorisation> getByPeronneEtSalle(long idPersonne, long idSalle) throws Exception {
        try {
            Salle salle = MetierFactory.getSalleService().getById(idSalle);
            Personne personne = MetierFactory.getPersonneService().getById(idPersonne);
            return this.autorisationService.getByPeronneEtSalle(personne, salle);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @POST
    @Path("/")
    public Autorisation add(Autorisation t) throws Exception {
        try {
            return this.autorisationService.add(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @DELETE
    @Path("/")
    public void remove(Autorisation t) throws Exception {
        try {
            this.autorisationService.remove(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @PUT
    @Path("/")
    public void update(Autorisation t) throws Exception {
        try {
            this.autorisationService.update(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/Count")
    public long getCount() throws Exception {
        try {
            return this.autorisationService.getCount();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/")
    public List<Autorisation> getAll() throws Exception {
        try {
            return this.autorisationService.getAll();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{begin}/{count}")
    public List<Autorisation> getAll(@PathParam("begin") int begin, @PathParam("count") int count) throws Exception {
        try {
            return this.autorisationService.getAll(begin, count);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{id}")
    public Autorisation getById(Long id) throws Exception {
        try {
            return this.autorisationService.getById(id);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }
}
