package lml.snir.controleacces.metier.transactionnel;

import java.util.List;
import lml.snir.controleacces.metier.entity.TimeSlot;
import lml.snir.controleacces.physique.data.PhysiqueDataFactory;
import lml.snir.controleacces.physique.data.TimeSlotDataService;

/**
 *
 * @author fanou
 */
public class TimeSlotServiceImpl implements TimeSlotService {
    private final TimeSlotDataService ts;

    public TimeSlotServiceImpl() throws Exception {
        ts = PhysiqueDataFactory.getTimeSlotService();
    }

    @Override
    public TimeSlot add(TimeSlot t) throws Exception {
        return this.ts.add(t);
    }

    @Override
    public void remove(TimeSlot t) throws Exception {
        this.ts.remove(t);
    }

    @Override
    public void update(TimeSlot t) throws Exception {
        this.ts.update(t);
    }

    @Override
    public TimeSlot getById(Long l) throws Exception {
        return this.ts.getById(l);
    }

    @Override
    public long getCount() throws Exception {
        return this.ts.getCount();
    }

    @Override
    public List<TimeSlot> getAll() throws Exception {
        return this.ts.getAll();
    }

    @Override
    public List<TimeSlot> getAll(int i, int i1) throws Exception {
        return this.ts.getAll(i, i1);
    }
    
}
