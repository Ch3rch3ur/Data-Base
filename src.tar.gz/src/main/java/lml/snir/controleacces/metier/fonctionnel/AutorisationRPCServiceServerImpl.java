package lml.snir.controleacces.metier.fonctionnel;

import lml.snir.controleacces.metier.transactionnel.AttributionService;
import lml.snir.controleacces.metier.transactionnel.AutorisationService;
import java.util.Date;
import java.util.List;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Attribution;
import lml.snir.controleacces.metier.entity.Autorisation;
import lml.snir.controleacces.metier.entity.Badge;
import lml.snir.controleacces.metier.entity.Evenement;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.controleacces.metier.entity.Salle;
import lml.snir.controleacces.metier.transactionnel.BadgeService;
import lml.snir.controleacces.metier.transactionnel.SalleService;

/**
 *
 * @author fanou
 */
public class AutorisationRPCServiceServerImpl implements AutorisationRPCService {
    private final BadgeService badgeSrv;
    private final SalleService salleSrv;
    private final AttributionService attrSrv;
    private final AutorisationService authSrv;
    
    public AutorisationRPCServiceServerImpl () throws Exception {
        this.badgeSrv = MetierFactory.getBadgeService();
        this.salleSrv =  MetierFactory.getSalleService();
        this.attrSrv = MetierFactory.getAttributionService();
        this.authSrv = MetierFactory.getAutorisationService();
    }

    /**
     * This method checks if the person who passes their RFID tags has the right
     * to do it enter this room at this moment and all events are recorded in
     * the database. The tag reader sends the content of the tag, the first step
     * is to retrieve the corresponding tag from the database. then the system
     * needs to retrieve the owner of the tag. At this time the system can check
     * the authorization of the owner of the tag for this room at this time
     * slot.
     *
     * @param badgeContent : the content of the RFID tag read by the RFID reader
     * present near the door.
     * @param salle : the number of the room protected by the system.
     * @return : the authorization status to open the door OR NOT.
     * @throws Exception
     */
    @Override
    public Boolean isAutorise(String badgeContent, Integer salle) throws Exception {
        Personne p = null;
        // retreive the actual date / time
        Date d = new Date();
        System.out.println("isAutorise( " + badgeContent + " , " + salle + " ' " + d + " )");

        boolean autorized = false;
        // The tag reader sends the content of the tag, the first step is to retrieve the tag correspondent into the database.
        System.out.print("this.badgeSrv.getByContenu(badgeContent) => ");
        Badge b = this.badgeSrv.getByContenu(badgeContent);
        System.out.println(b);

        // Retreive object salle with it's number into database
        System.out.print("this.salleSrv.getById((long) salle) => ");
        Salle s = this.salleSrv.getById((long) salle);
        System.out.println(s);

        // check salle exist
        if (s != null) {
            // check if salle is protected or not
            if (!s.isProtege()) {
                // not protected all is granted
                System.out.println("isAutorise : Salle non protégée !");
                autorized = true;
            } else {
                // retreive the badge objet and it's owner
                if (b != null) {
                    // to do that you need to retreive attribution by 'badge'
                    Attribution attr = this.attrSrv.getByBadge(b);
                    if (attr != null) {
                        // if attribution exist for this badge get autorization for the owner
                        p = attr.getPersonne();
                        
                        // get the autorisation thor this people and salle
                        List<Autorisation> autorisations = this.authSrv.getByPeronneEtSalle(p, s);
                        for (Autorisation a : autorisations) {
                            // check if time slot is ok
                            if (a.getPlageHoraire().isIn(d)) {
                                autorized = true;
                                break;
                            }
                        }
                    } else {
                        System.out.println("isAutorise : Badge non attribué !");
                    }

                } else {
                    System.out.println("isAutorise : Badge inconnue !");
                }
            }
        } else {
            System.out.println("isAutorise : Salle inconnue !");
        }

        if (p != null) {
            // create event
            Evenement evt = new Evenement();
            evt.setAutorise(autorized);
            evt.setDate(d);
            evt.setPersonne(p);
            evt.setSalle(s);

            evt = MetierFactory.getEvenementService().add(evt);
            System.out.println("isAutorise : " + evt);
        }

        return autorized;
    }
}