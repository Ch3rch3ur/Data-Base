package lml.snir.controleacces.metier;

import java.util.logging.Level;
import java.util.logging.Logger;
import lml.snir.controleacces.metier.fonctionnel.AutorisationRPCServiceServerImpl;
import lml.snir.controleacces.metier.fonctionnel.AutorisationRPCService;
import lml.snir.controleacces.metier.transactionnel.AttributionService;
import lml.snir.controleacces.metier.transactionnel.EvenementServiceImpl;
import lml.snir.controleacces.metier.transactionnel.AutorisationServiceImpl;
import lml.snir.controleacces.metier.transactionnel.BadgeServiceImpl;
import lml.snir.controleacces.metier.transactionnel.PersonneService;
import lml.snir.controleacces.metier.transactionnel.AttributionServiceImpl;
import lml.snir.controleacces.metier.transactionnel.SalleService;
import lml.snir.controleacces.metier.transactionnel.BadgeService;
import lml.snir.controleacces.metier.transactionnel.TimeSlotServiceImpl;
import lml.snir.controleacces.metier.transactionnel.PersonneServiceImpl;
import lml.snir.controleacces.metier.transactionnel.SalleServiceImpl;
import lml.snir.controleacces.metier.transactionnel.TimeSlotService;
import lml.snir.controleacces.metier.transactionnel.AutorisationService;
import lml.snir.controleacces.metier.transactionnel.EvenementService;

public class MetierFactory {  

    private static BadgeService badgeService;    
    public static BadgeService getBadgeService() throws Exception {  
        if (badgeService == null) {
            badgeService = new BadgeServiceImpl();
        }
        return badgeService;
    }

    private static AttributionService attributionService;   
    public static AttributionService getAttributionService() throws Exception {
        if (attributionService == null) {
            attributionService = new AttributionServiceImpl();
        }
        return attributionService;
    }

    private static AutorisationService autorisation;
    public static AutorisationService getAutorisationService() throws Exception {
        if (autorisation == null) {
            autorisation = new AutorisationServiceImpl();
        }
        return autorisation;
    }

    private static EvenementService evenementService; 
    public static EvenementService getEvenementService() throws Exception {
        if (evenementService == null) {
            evenementService = new EvenementServiceImpl();
        }
        return evenementService;
    }

    private static PersonneService personneService;   
    public static PersonneService getPersonneService() throws Exception {
        if (personneService == null) {
            personneService = new PersonneServiceImpl();
        }
        return personneService;
    }
    
    private static SalleService salleService;
    public static SalleService getSalleService() throws Exception {
        if (salleService == null) {
            salleService = new SalleServiceImpl();
        }
        return salleService;
    }
    
    private static AutorisationRPCService autorisationRPCService;
    public static AutorisationRPCService getAutorisationRPCService() {
        if (autorisationRPCService == null) {
            try {
                autorisationRPCService = new AutorisationRPCServiceServerImpl();
            } catch (Exception ex) {
                Logger.getLogger(MetierFactory.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("lml.snir.controleacces.metier.MetierFactory.getAutorisationRPCService() error => " + ex.getMessage());
            }
        }
        return autorisationRPCService;
    }

    private static TimeSlotService ts;
    public static TimeSlotService getTimeSlotService() throws Exception {
        if (ts == null) {
            ts = new TimeSlotServiceImpl();
        }
        return ts;
    }
    
    private MetierFactory(){}

}
