package lml.snir.controleacces.metier.rest.serveur;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.transactionnel.TimeSlotService;
import lml.snir.controleacces.metier.entity.TimeSlot;
import lml.snir.rest.server.RestException;

@Path("/TimeSlotService")
@Consumes("application/json")
@Produces("application/json")
public class TimeSlotServiceRESTSRVImpl {

    private final TimeSlotService timeSlotService = MetierFactory.getTimeSlotService();
    public TimeSlotServiceRESTSRVImpl() throws Exception {
        
    }

    @POST
    @Path("/")
    public TimeSlot add(TimeSlot t) throws Exception {
        try {
            return this.timeSlotService.add(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @DELETE
    @Path("/")
    public void remove(TimeSlot t) throws Exception {
        try {
            this.timeSlotService.remove(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @PUT
    @Path("/")
    public void update(TimeSlot t) throws Exception {
        try {
            this.timeSlotService.update(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/Count")
    public long getCount() throws Exception {
        try {
            return this.timeSlotService.getCount();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/")
    public List<TimeSlot> getAll() throws Exception {
        try {
            return this.timeSlotService.getAll();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{begin}/{count}")
    public List<TimeSlot> getAll(@PathParam("begin") int begin, @PathParam("count") int count) throws Exception {
        try {
            return this.timeSlotService.getAll(begin, count);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{id}")
    public TimeSlot getById(Long id) throws Exception {
        try {
            return this.timeSlotService.getById(id);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }
}
