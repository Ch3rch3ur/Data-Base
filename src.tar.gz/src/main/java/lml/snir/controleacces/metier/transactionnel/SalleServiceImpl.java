package lml.snir.controleacces.metier.transactionnel;

import java.util.List;
import lml.snir.controleacces.metier.entity.Salle;
import lml.snir.controleacces.physique.data.PhysiqueDataFactory;
import lml.snir.controleacces.physique.data.SalleDataService;

/**
 *
 * @author fanou
 */
public final class SalleServiceImpl implements SalleService {

    private final SalleDataService salleDataSrv;

    public SalleServiceImpl() throws Exception {
        salleDataSrv = PhysiqueDataFactory.getSalleDataService();
    }

    @Override
    public List<Salle> getByProtege(boolean protege) throws Exception {
        return this.salleDataSrv.getByProtege(protege);
    }

    @Override
    public Salle add(Salle t) throws Exception {
        try {
            return this.salleDataSrv.add(t);
        } catch (Exception ex) {
            String st = ex.getMessage();
            if (st.contains("SQL : 19")) {
                throw new Exception("Salle déjà enregistrée");
            } else {
                throw ex;
            }
        }
    }

    @Override
    public void remove(Salle t) throws Exception {
        this.salleDataSrv.remove(t);
    }

    @Override
    public void update(Salle t) throws Exception {
        this.salleDataSrv.update(t);
    }

    @Override
    public Salle getById(Long l) throws Exception {
        return this.salleDataSrv.getById(l);
    }

    @Override
    public long getCount() throws Exception {
        return this.salleDataSrv.getCount();
    }

    @Override
    public List<Salle> getAll() throws Exception {
        return this.salleDataSrv.getAll();
    }

    @Override
    public List<Salle> getAll(int i, int i1) throws Exception {
        return this.salleDataSrv.getAll(i, i1);
    }

}
