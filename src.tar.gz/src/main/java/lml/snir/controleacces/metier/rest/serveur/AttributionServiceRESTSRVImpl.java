package lml.snir.controleacces.metier.rest.serveur;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Attribution;
import lml.snir.controleacces.metier.entity.Badge;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.rest.server.RestException;
import lml.snir.controleacces.metier.transactionnel.AttributionService;

@Path("/AttributionService")
@Consumes("application/json")
@Produces("application/json")
public class AttributionServiceRESTSRVImpl {

    private final AttributionService attributionService = MetierFactory.getAttributionService();
    public AttributionServiceRESTSRVImpl() throws Exception {
        
    }

    @GET
    @Path("/getByBadge/{idBadge}")
    public Attribution getByBadge(@PathParam("idBadge") long idBadge) throws Exception {
        try {
            Badge badge = MetierFactory.getBadgeService().getById(idBadge);
            if (badge == null) {
                return null;
            }
            return this.attributionService.getByBadge(badge);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/getByUtilisateur/{idUtilisateur}")
    public Attribution getByUtilisateur(@PathParam("idUtilisateur") long idUtilisateur) throws Exception {
        try {
            Personne personne = MetierFactory.getPersonneService().getById(idUtilisateur);
            return this.attributionService.getByPersonne(personne);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @POST
    @Path("/")
    public Attribution add(Attribution t) throws Exception {
        try {
            return this.attributionService.add(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @DELETE
    @Path("/")
    public void remove(Attribution t) throws Exception {
        try {
            this.attributionService.remove(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @PUT
    @Path("/")
    public void update(Attribution t) throws Exception {
        try {
            this.attributionService.update(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/Count")
    public long getCount() throws Exception {
        try {
            return this.attributionService.getCount();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/")
    public List<Attribution> getAll() throws Exception {
        try {
            return this.attributionService.getAll();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{begin}/{count}")
    public List<Attribution> getAll(@PathParam("begin") int begin, @PathParam("count") int count) throws Exception {
        try {
            return this.attributionService.getAll(begin, count);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{id}")
    public Attribution getById(@PathParam("id") Long id) throws Exception {
        try {
            return this.attributionService.getById(id);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }
}
