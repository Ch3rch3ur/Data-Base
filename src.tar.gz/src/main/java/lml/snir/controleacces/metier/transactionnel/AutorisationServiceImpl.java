package lml.snir.controleacces.metier.transactionnel;

import java.util.List;
import lml.snir.controleacces.metier.entity.Autorisation;
import lml.snir.controleacces.metier.entity.Personne;
import lml.snir.controleacces.metier.entity.Salle;
import lml.snir.controleacces.metier.entity.TimeSlot;
import lml.snir.controleacces.physique.data.AutorisationDataService;
import lml.snir.controleacces.physique.data.PhysiqueDataFactory;

public class AutorisationServiceImpl implements AutorisationService {

    private final AutorisationDataService autorisationSrv;

    public AutorisationServiceImpl() throws Exception {
        autorisationSrv = PhysiqueDataFactory.getAutorisationDataService();
    }

    @Override
    public Autorisation add(Autorisation authorisation) throws Exception {
        // check if personne selected
        if (authorisation.getPersonne() == null) {
            throw new Exception("aucune personne de selectionnée");
        }
        
        // check if PlageHoraire is selected
        if (authorisation.getPlageHoraire() == null) {
            throw new Exception("aucune Plage Horaire de selectionné");
        }
        
        // check if salle is selected
        if (authorisation.getSalle()== null) {
            throw new Exception("aucune salle de selectionné");
        }
        
        // check if this a same autoristion is prssent
        List<Autorisation> autorisations = getByPeronneEtSalle(authorisation.getPersonne(), authorisation.getSalle());
        for (Autorisation aut : autorisations) {
            if (aut.getPlageHoraire().equals(authorisation.getPlageHoraire())) {
                throw new Exception("une autorisation similaire existe déjà !");
            }
        }
                
        return this.autorisationSrv.add(authorisation);
    }

    @Override
    public void remove(Autorisation authorisation) throws Exception {
        this.autorisationSrv.remove(authorisation);
    }

    @Override
    public void update(Autorisation authorisation) throws Exception {
        this.autorisationSrv.update(authorisation);
    }

    @Override
    public List<Autorisation> getAll(int debut, int count) throws Exception {
        return this.autorisationSrv.getAll(debut, count);
    }

    @Override
    public List<Autorisation> getBySalle(Salle salle) throws Exception {
        return this.autorisationSrv.getBySalle(salle);
    }

    @Override
    public List<Autorisation> getByPersonne(Personne personne) throws Exception {
        return this.autorisationSrv.getByPersonne(personne);
    }

    @Override
    public List<Autorisation> getByPeronneEtSalle(Personne personne, Salle salle) throws Exception {
        return this.autorisationSrv.getByPeronneEtSalle(personne, salle);
    }

    @Override
    public Autorisation getById(Long id) throws Exception {
        return this.autorisationSrv.getById(id);
    }

    @Override
    public long getCount() throws Exception {
        return this.autorisationSrv.getCount();
    }

    @Override
    public List<Autorisation> getAll() throws Exception {
        return this.autorisationSrv.getAll();
    }

    @Override
    public List<Autorisation> getByPlageHoraire(TimeSlot plageHoraire) throws Exception {
        return this.autorisationSrv.getByPlageHoraire(plageHoraire);
    }    
}
