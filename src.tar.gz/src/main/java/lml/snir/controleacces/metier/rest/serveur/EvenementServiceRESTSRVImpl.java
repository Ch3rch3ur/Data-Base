package lml.snir.controleacces.metier.rest.serveur;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import lml.snir.controleacces.metier.transactionnel.EvenementService;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Evenement;
import lml.snir.controleacces.metier.entity.Salle;
import lml.snir.rest.server.RestException;

@Path("/EvenementService")
@Consumes("application/json")
@Produces("application/json")
public class EvenementServiceRESTSRVImpl {

    private final EvenementService eventService = MetierFactory.getEvenementService();
    public EvenementServiceRESTSRVImpl() throws Exception {
        
    }

    @GET
    @Path("/getByJour/{strDate}")
    public List<Evenement> getByJour(@PathParam("strDate") String strDate) throws Exception {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date jour = sdf.parse(strDate);
            return this.eventService.getByJour(jour);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/getBySalle/{idSalle}")
    public List<Evenement> getBySalle(@PathParam("idSalle") long idSalle) throws Exception {
        try {
            Salle salle = MetierFactory.getSalleService().getById(idSalle);
            return this.eventService.getBySalle(salle);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @POST
    @Path("/")
    public Evenement add(Evenement t) throws Exception {
        try {
            return this.eventService.add(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @DELETE
    @Path("/")
    public void remove(Evenement t) throws Exception {
        try {
            this.eventService.remove(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @PUT
    @Path("/")
    public void update(Evenement t) throws Exception {
        try {
            this.eventService.update(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/Count")
    public long getCount() throws Exception {
        try {
            return this.eventService.getCount();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/")
    public List<Evenement> getAll() throws Exception {
        try {
            return this.eventService.getAll();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{begin}/{count}")
    public List<Evenement> getAll(@PathParam("begin") int begin, @PathParam("count") int count) throws Exception {
        try {
            return this.eventService.getAll(begin, count);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{id}")
    public Evenement getById(Long id) throws Exception {
        try {
            return this.eventService.getById(id);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }
}
