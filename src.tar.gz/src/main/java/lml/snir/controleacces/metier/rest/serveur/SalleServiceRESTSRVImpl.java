package lml.snir.controleacces.metier.rest.serveur;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import lml.snir.controleacces.metier.transactionnel.SalleService;
import lml.snir.controleacces.metier.MetierFactory;
import lml.snir.controleacces.metier.entity.Salle;
import lml.snir.rest.server.RestException;

/**
 *
 * @author fanou
 */
@Path("/SalleService")
@Consumes("application/json")
@Produces("application/json")
public class SalleServiceRESTSRVImpl {

    private final SalleService salleService = MetierFactory.getSalleService();
    public SalleServiceRESTSRVImpl() throws Exception {
        
    }

//    @GET
//    @Path("/getByBadge/{idBadge}")
//    public Salle getByBadge(@PathParam("idBadge") long idBadge) throws Exception {        
//        Badge badge = MetierFactory.getBadgeService().getById(idBadge);
//        return this.salleService.getByBadge(badge);
//    }
//
//    @GET
//    @Path("/getByUtilisateur/{idPersonne}")
//    public Salle getByUtilisateur(@PathParam("idPersonne") long idPersonne) throws Exception {
//        Personne personne = MetierFactory.getPersonneService().getById(idPersonne);
//        return this.salleService.getByPersonne(personne);
//    }
    @POST
    @Path("/")
    public Salle add(Salle t) throws Exception {
        try {
            return this.salleService.add(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @DELETE
    @Path("/")
    public void remove(Salle t) throws Exception {
        try {
            this.salleService.remove(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @PUT
    @Path("/")
    public void update(Salle t) throws Exception {
        try {
            this.salleService.update(t);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/Count")
    public long getCount() throws Exception {
        try {
            return this.salleService.getCount();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/")
    public List<Salle> getAll() throws Exception {
        try {
            return this.salleService.getAll();
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{begin}/{count}")
    public List<Salle> getAll(@PathParam("begin") int begin, @PathParam("count") int count) throws Exception {
        try {
            return this.salleService.getAll(begin, count);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }

    @GET
    @Path("/{id}")
    public Salle getById(@PathParam("id") Long id) throws Exception {
        try {
            return this.salleService.getById(id);
        } catch (Exception ex) {
            throw new RestException(500, ex.getMessage());
        }
    }
}
